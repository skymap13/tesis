const environment = 'Local';

//Local, Development, Production

const configs = {
    Local: {
        db_host: 'localhost',
        db_user: 'root',
        db_pass: 'admin1234',
        db_database: 'vernellydb',
        db_port: 3306,
    },
    Server: {
        db_host: 'ipdelservidor',
        db_user: 'usuario',
        db_pass: 'clave',
        db_database: 'vernellydb',
        db_port: 3306,
    },
    Production: {

    }
};

module.exports = configs[environment];