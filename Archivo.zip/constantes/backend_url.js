const environment = 'Local';

const configs = {
    Local: {
        backendURL: 'http://localhost:5000',
        backendPORT: '5000',
        jwt_tiempo_expira: '1d'
    },
    Server: {
        backendURL: 'http://ipdeservidor:5000',
        backendPORT: '5000',
        jwt_tiempo_expira: '1d',
    },
    Production: {

    }
};

module.exports = configs[environment];