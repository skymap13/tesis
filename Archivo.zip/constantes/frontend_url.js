const environment = 'Local';

const configs = {
    Local: {
        frontendURL: 'http://localhost:3000',
        frontendPORT: '5000',
        jwt_tiempo_expira: '1d'
    },
    Server: {
        frontendURL: 'http://ipdeservidor:3000',
        frontendPORT: '5000',
        jwt_tiempo_expira: '1d',
    },
    Production: {

    }
};

module.exports = configs[environment];