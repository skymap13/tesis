# vernellydetalles
 
