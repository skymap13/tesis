var sha512 = require('js-sha512').sha512;
var sha512_256 = require('js-sha512').sha512_256;
var md5 = require('md5');
const key_AES="vernelly123"
function encriptar_md5(texto) {
  return md5(texto);
}
function encriptar_sha256(texto) {
  return sha512_256(texto);
}
function encriptar_sha512(texto) {
  let encript=sha512(texto);
  return encript;
}

module.exports = {
  encriptar_md5,
  encriptar_sha256,
  encriptar_sha512,
};
