const objToken = require("./fToken");
const objSql = require("./fSql");
const objFec = require("./fFechas");
const connection = require('../database/db.js');

async function validarIdentidadUsuario(variables, res) {
  const cadenasql1 = "SELECT USUA_CODIGO,USUA_NOMBRE, USUA_APELLIDO, USUA_CORREO, vn_configuracion_usuarios.PERF_CODIGO FROM vn_configuracion_usuarios WHERE USUA_CORREO = ? AND USUA_CLAVE = ? AND USUA_ESTADO=?;";
  console.log("ENTRO A validar_identidad_usuario ");
  console.log(variables);
  try {
    connection.query(cadenasql1, variables, (error, result) => {
      console.log("result: ", result)
      if (error) {
        console.log(error);
        res.status(500).json({ message: "ERROR EN BASE DE DATOS", error: error.toString() });
        return;
      }

      if (result.length === 0) {
        return res.status(401).json({ mensaje: "USUARIO O CONTRASEÑA INCORRECTO/A" });
      } else {
        var token_generado = objToken.generateToken_JWT(result[0]["USUA_CODIGO"]);
        return res.status(200).json({
          name: result[0]["USUA_NOMBRE"],
          lastname: result[0]["USUA_APELLIDO"],
          token: token_generado,
          perfil: result[0].PERF_CODIGO
        });
        /*const valores = [
          result[0]["USUA_CODIGO"],
          result[0]["USUA_NOMBRE"],
          nickname,
          objFec.fecha_hora_actual(),
          "SN",
          "ACCESADO",
          "USUARIO",
          "SI",
          token_generado,
          "SN",
          "MOVIL",
          "Abierta",
          token_generado
        ];
        const campos = [
          "LOUS_CODUSE",
          "LOUS_NOMBRE",
          "LOUS_CORREO",
          "LOUS_FECHAX",
          "LOUS_HOSTXX",
          "LOUS_ESTADO",
          "LOUS_TIPOXX",
          "LOUS_USUSIS",
          "LOUS_TOKENX",
          "LOUS_USERAG",
          "LOUS_APLICA",
          "LOUS_ESTSES",
          "LOUS_IDSESS"
        ];*/
        //objSql.insertarDatos("sy_seguridad_logusuario", campos, valores, res);
      }
    });
  } catch (error) {
    res.status(500).json({ message: "ERROR EN BASE DE DATOS", error: error.toString() });
  }
}

async function obtenerDatosUser(codigo, callback) {
  const comando = "SELECT USUA_NOMBRE, USUA_APELLIDO, USUA_CODIGO FROM vn_configuracion_usuarios WHERE USUA_CODIGO=?";
  console.log("ENTRO A obtenerDatosUser ");
  try {

    connection.query(comando, [codigo], (err, result) => {
      console.log(result);
      callback(null, result[0]);

    });


  } catch (error) {
    console.log(error);
    console.log('--------------------------------------------------------------')
    console.error("Error en obtenerDatosUser:", error);
    throw error;
  }
}

module.exports = {
  validarIdentidadUsuario,
  obtenerDatosUser
};
