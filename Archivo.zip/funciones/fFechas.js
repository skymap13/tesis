const moment = require('moment-timezone');

function fecha_hora_actual() {
    var fecha = moment().tz('America/Guayaquil');
    console.log('fecha_hora_actual: ', fecha.format('YYYY-MM-DD HH:mm:ss'))
    return fecha.format('YYYY-MM-DD HH:mm:ss');
}
function fecha_hora_actual_NOFORMAT() {
    var fecha = moment().tz('America/Guayaquil');
    console.log('fecha_hora_actual_NOFORMAT: ', fecha.toDate());
    return fecha;
}

function fecha_actual() {
    var fecha = new Date();
    var anio = fecha.getFullYear();
    var mes = fecha.getMonth() + 1;
    var dia = fecha.getDate();
    var fechaF = anio + "-" + mes + "-" + dia;
    return fechaF;
}

function getYear() {
    var fecha = new Date();
    var anio = fecha.getFullYear();
    return anio;
}

function getDay() {
    var fecha = new Date();
    var dia = fecha.getDate();
    return dia;
}

function getMonth() {
    var fecha = new Date()
    var mes = fecha.getMonth();
    return mes;
}

function obtener_hora(hora) {
    var horaNum = Number(hora);
    return horaNum;
}

function obtener_minuto(min) {
    var minNum = Number(min);
    return minNum;
}

function semana_letras(day) {
    let days = ["", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
    date = days[day];
    return date;
}

function mes_letras(month) {
    let months = ["", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    date = months[month];
    return date;
}
function convertirFormatoFecha(fecha) {
    var fechaObj = new Date(fecha);
    const fechaBase = new Date('1900-01-01');
    const fechaF = new Date(fechaBase.getTime() + (fecha - 1) * 24 * 60 * 60 * 1000);

    var dia = fechaF.getDate();
    var mes = fechaF.getMonth() + 1;
    var anio = fechaF.getFullYear();

    var fechaFormateada = anio + '-' + (mes < 10 ? ("0" + mes) : mes) + '-' + dia;

    return fechaFormateada.toString();
}

function compararFechas(date1, date2) {
    console.log(date1);
    console.log(date2);

    // Convertir ambas fechas a la misma zona horaria
    const fecha1 = moment(date1).tz('America/Guayaquil');
    const fecha2 = moment(date2).tz('America/Guayaquil');

    console.log('Fecha 1:', fecha1.format());
    console.log('Fecha 2:', fecha2.format());

    // Calcular la diferencia en minutos
    const diferenciaEnMinutos = fecha1.diff(fecha2, 'minutes');
    console.log('Diferencia en minutos:', diferenciaEnMinutos);

    return diferenciaEnMinutos > 0;
}

module.exports = {
    fecha_actual,
    fecha_hora_actual,
    getYear,
    getDay,
    getMonth,
    semana_letras,
    mes_letras,
    obtener_hora,
    obtener_minuto,
    convertirFormatoFecha,
    compararFechas,
    fecha_hora_actual_NOFORMAT
};
