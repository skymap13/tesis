const jwt = require("jsonwebtoken");
const verify_jwt="genova789";
//seguridad token JWT
const generateToken_JWT = (id) => {
  return jwt.sign({ id }, verify_jwt, {
    expiresIn: "1d",
  });
};
function obtener_id_usuario(token) {
  const decoded = jwt.verify(token, verify_jwt);
  return decoded.id;
}

function verificar_token(token){
  //console.log("llego a verificar token")
  const encoder=new TextEncoder();
  let result=jwt.verify(token, verify_jwt);
  console.log(result);
  const iatFormatted = convertirFecha(result.iat);
  const expFormatted = convertirFecha(result.exp);

  /*console.log(`Fecha iat: ${iatFormatted}`);
  console.log(`Fecha exp: ${expFormatted}`);*/
  return [iatFormatted, expFormatted];
}
function convertirFecha(timestamp) {
  const date = new Date(timestamp * 1000); // Multiplica por 1000 para convertir de segundos a milisegundos
  console.log(date);
  const dia = date.getDate().toString().padStart(2, '0'); // Obtener el día y asegurar que tenga 2 dígitos
  const mes = (date.getMonth() + 1).toString().padStart(2, '0'); // Obtener el mes (se indexa desde 0) y asegurar que tenga 2 dígitos
  const anio = date.getFullYear().toString(); // Obtener el año
  
  return `${dia}-${mes}-${anio}`;
}
module.exports = {
    generateToken_JWT,
    obtener_id_usuario,
    verificar_token
};
