const conexion = require("../database/db");
const _ = require("underscore");

exports.insertar = function (tabla, campos, valores, res, mensaje = "Datos insertados correctamente") {
    try {
        if (campos.length !== valores.length) {
            throw new Error("La cantidad de campos no coincide con la cantidad de valores.");
        }

        const placeholders = valores.map(() => "?").join(", ");

        const cadena = `INSERT INTO ${tabla} (${campos.join(", ")}) VALUES (${placeholders})`;

        conexion.query(cadena, valores, function (error, resultados) {
            if (error) {
                if (error.code === 'ER_DUP_ENTRY')
                    res.status(500).json({ error: "La relación ya existe" });
                else res.status(500).json({ error: "Error interno del servidor" });
            }
            else res.status(200).json({ mensaje: mensaje, result: resultados });
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
};

exports.insertarSinRepetir = function (tabla, campos, valores, camposUnicos, res, mensaje = "Datos insertados correctamente") {
    try {
        console.log('insertando sin repetir')
        if (campos.length !== valores.length) {
            throw new Error("La cantidad de campos no coincide con la cantidad de valores.");
        }

        const placeholders = valores.map(() => "?").join(", ");
        const cadena = `INSERT INTO ${tabla} (${campos.join(", ")}) VALUES (${placeholders})`;

        // Crear consulta para verificar duplicados
        const condiciones = camposUnicos.map(campo => `${campo} = ?`).join(" AND ");
        const valoresCondiciones = camposUnicos.map(campo => valores[campos.indexOf(campo)]);
        const cadenaVerificacion = `SELECT COUNT(*) AS count FROM ${tabla} WHERE ${condiciones}`;
        // Verificar duplicados
        conexion.query(cadenaVerificacion, valoresCondiciones, function (error, resultados) {
            if (error) {
                console.log(error);
                return res.status(500).json({ error: "Error interno del servidor" });
            }
            if (resultados[0]?.count > 0) {
                return res.status(400).json({ error: "Los datos ya existen en la base de datos." });
            }

            // Insertar datos si no hay duplicados
            conexion.query(cadena, valores, function (error, resultados) {
                if (error) {
                    if (error.code === 'ER_DUP_ENTRY') {
                        return res.status(500).json({ error: "La relación ya existe" });
                    } else {
                        return res.status(500).json({ error: "Error interno del servidor" });
                    }
                }
                //6IWy6JZw5WanS60cNbzdh0uqBUNzRN7S433622922_4071624389731326_9216099118887256613_n.jpg
                //6IWy6JZw5WanS60cNbzdh0uqBUNzRN7S433622922_4071624389731326_9216099118887256613_n.jpg
                console.log('se insertaron productos')
                return res.status(200).json({ mensaje: mensaje, result: resultados });
            });
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
};

exports.actualizarSinRes = function (tabla, campos, valores, condicion) {
    try {
        /*if (campos.length !== valores.length) {
            throw new Error("La cantidad de campos no coincide con la cantidad de valores.");
        }*/
        var values = "";
        //const placeholders = valores.map(() => "?").join(", ");
        for (let i = 0; i < campos.length; i++) {
            if (i < (campos.length - 1)) values += campos[i] + '= ?, ';
            else values += campos[i] + "= ?";
        }
        const cadena = `UPDATE ${tabla} SET ${values} WHERE ${condicion}`;

        conexion.query(cadena, valores, function (error, resultados) {
            if (error) {
                console.log(error);
                //res.status(500).json({ error: "Error interno del servidor" });
            }
            //else res.status(200).json({ mensaje: "Datos actualizados correctamente", resultados });
        });
    } catch (error) {
        console.error(error);
        //res.status(500).json({ error: "Error interno del servidor" });
    }
};

exports.listarPaginacion = async function (tabla, campos, campos_busqueda, page, valorBusqueda, limit, condicion, res) {
    try {
        const offset = (page - 1) * limit;
        const searchTerms = `%${valorBusqueda}%`;
        console.log('searchTerms: ', searchTerms)
        let query = `SELECT ${campos.join(', ')} FROM ${tabla} WHERE (`;
        let queryCount = `SELECT COUNT(*) as total FROM ${tabla} WHERE (`;

        if (Array.isArray(campos_busqueda)) {
            campos_busqueda.forEach((campo_busqueda, index) => {
                queryCount += `${campo_busqueda} LIKE ?`;
                if (index < campos_busqueda.length - 1) {
                    queryCount += ' OR ';
                }
            });
        } else {
            queryCount += `${campos_busqueda} LIKE ?`;
        }
        queryCount += `) ${condicion}`;
        console.log('queryCount: ', queryCount)
        let queryParamsCount = Array.isArray(campos_busqueda) ? campos_busqueda.map(() => searchTerms) : searchTerms;

        //const [countRows] = conexion.query(queryCount, queryParamsCount);
        conexion.query(queryCount, queryParamsCount, function (error, countRows) {
            if (error) {
                console.log(error);
                res.status(500).json({ error: "Error interno del servidor" });
                return
            }

            let totalPages = Math.ceil(countRows[0].total / parseInt(limit));

            if (Array.isArray(campos_busqueda)) {
                campos_busqueda.forEach((campo_busqueda, index) => {
                    query += `${campo_busqueda} LIKE ?`;
                    if (index < campos_busqueda.length - 1) {
                        query += ' OR ';
                    }
                });
            } else {
                query += `${campos_busqueda} LIKE ?`;
            }
            query += `) ${condicion} LIMIT ?, ?`;

            let queryParams = Array.isArray(campos_busqueda) ? campos_busqueda.map(() => searchTerms) : searchTerms;

            queryParams.push(offset, parseInt(limit));
            //const [rows, fields] = db.query(query, queryParams);
            conexion.query(query, queryParams, function (error, resultList) {
                if (error) {
                    console.log(error);
                    res.status(500).json({ error: "Error interno del servidor" });
                    return;
                }
                res.status(200).json({ result: resultList, pages: totalPages, page });
                return;
            });
        });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ error: 'Error fetching products' });
    }
}

exports.listarPaginacionRelaciones = async function (tabla, campos, campos_busqueda, page, valorBusqueda, limit, res, joinTable, joinCondition1, joinCondition2) {
    try {
        const offset = (page - 1) * limit;
        const searchTerms = `%${valorBusqueda}%`;
        console.log('searchTerms: ', searchTerms);
        let query = `SELECT ${campos.join(', ')} FROM ${tabla} LEFT JOIN ${joinTable} ON ${joinCondition1} = ${joinCondition2} WHERE `;
        let queryCount = `SELECT COUNT(*) as total FROM ${tabla} LEFT JOIN ${joinTable} ON ${joinCondition1} = ${joinCondition2} WHERE `;

        if (Array.isArray(campos_busqueda)) {
            campos_busqueda.forEach((campo_busqueda, index) => {
                queryCount += `${campo_busqueda} LIKE ?`;
                if (index < campos_busqueda.length - 1) {
                    queryCount += ' OR ';
                }
            });
        } else {
            queryCount += `${campos_busqueda} LIKE ?`;
        }
        let queryParamsCount = Array.isArray(campos_busqueda) ? campos_busqueda.map(() => searchTerms) : searchTerms;

        conexion.query(queryCount, queryParamsCount, function (error, countRows) {
            if (error) {
                console.log(error);
                res.status(500).json({ error: "Error interno del servidor" });
                return;
            }

            let totalPages = Math.ceil(countRows[0].total / parseInt(limit));

            if (Array.isArray(campos_busqueda)) {
                campos_busqueda.forEach((campo_busqueda, index) => {
                    query += `${campo_busqueda} LIKE ?`;
                    if (index < campos_busqueda.length - 1) {
                        query += ' OR ';
                    }
                });
            } else {
                query += `${campos_busqueda} LIKE ?`;
            }
            query += ` LIMIT ?, ?`;

            let queryParams = Array.isArray(campos_busqueda) ? campos_busqueda.map(() => searchTerms) : searchTerms;
            queryParams.push(offset, parseInt(limit));

            conexion.query(query, queryParams, function (error, resultList) {
                if (error) {
                    console.log(error);
                    res.status(500).json({ error: "Error interno del servidor" });
                    return;
                }
                res.status(200).json({ result: resultList, pages: totalPages, page });
                return;
            });
        });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ error: 'Error fetching products' });
    }
}


exports.actualizar = function (tabla, campos, valores, condicion, res) {
    try {
        /*if (campos.length !== valores.length) {
            throw new Error("La cantidad de campos no coincide con la cantidad de valores.");
        }*/
        var values = "";
        //const placeholders = valores.map(() => "?").join(", ");
        for (let i = 0; i < campos.length; i++) {
            if (i < (campos.length - 1)) values += campos[i] + '= ?, ';
            else values += campos[i] + "= ?";
        }
        const cadena = `UPDATE ${tabla} SET ${values} WHERE ${condicion}`;

        conexion.query(cadena, valores, function (error, resultados) {
            if (error) {
                console.log(error);
                res.status(500).json({ error: "Error interno del servidor" });
            }
            else res.status(200).json({ mensaje: "Datos actualizados correctamente", resultados });
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
};

exports.actualizarDatos = async function (tabla, camposValores, condicion, res) {
    const camposSet = Object.keys(camposValores).map((campo) => `${campo} = ?`).join(', ');
    const query = `UPDATE ${tabla} SET ${camposSet} WHERE ${condicion}`;

    const valores = Object.values(camposValores);
    console.log('query: ', query);
    console.log('valores: ', valores);

    try {
        conexion.query(query, valores, (err, result) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ result: null, mensaje: 'Error en la consulta' });
            }
            return res.status(200).json({ result, mensaje: 'Datos actualizados' });
        });
    } catch (error) {
        console.error('Error al actualizar datos:', error);
        res.status(500).json({ message: 'Error al actualizar datos', error: error.message });
    }
}

exports.actualizarVariosDatos = async function (tabla, camposActualizar, listaItems, condicion, res) {//exclusivo para actualizar el carrito de compras
 
      conexion.beginTransaction(async (err) => {
        if (err) {
          res.status(500).json({ error: "Error al iniciar la transacción" });
          conexion.release();
          return;
        }
  
        try {
          for (const item of listaItems) {
            const { id, cantidad } = item;
            const query = `UPDATE ${tabla} SET ${camposActualizar[0]} = ? ${condicion}`;
            await conexion.promise().execute(query, [cantidad, id]);
          }
  
          conexion.commit((err) => {
            if (err) {
                conexion.rollback(() => {
                res.status(500).json({ error: "Error al confirmar la transacción" });
                conexion.release();
              });
              return;
            }
            res.status(200).json({ mensaje: "Carrito actualizado correctamente" });
          });
        } catch (error) {
            conexion.rollback(() => {
            res.status(500).json({ error: "Error al actualizar el carrito" });
            conexion.release();
          });
        }
      });
    
  };
  


exports.insertarSinRespuesta = function (tabla, campos, valores) {
    try {
        if (campos.length !== valores.length) {
            throw new Error("La cantidad de campos no coincide con la cantidad de valores.");
        }

        const placeholders = valores.map(() => "?").join(", ");

        const cadena = `INSERT INTO ${tabla} (${campos.join(", ")}) VALUES (${placeholders})`;

        conexion.query(cadena, valores, function (error, resultados) {
            if (error) {
                throw error;
            }
            console.log("Datos insertados sin Response");
            //res.status(200).json({ mensaje: "Datos insertados correctamente", resultados });
        });
    } catch (error) {
        console.error(error);
        //res.status(500).json({ error: "Error interno del servidor" });
    }
};
exports.seleccionarTodosDatosTabla = async function (tabla, res) {
    const query = `SELECT * FROM ${tabla};`;

    try {
        console.log(query);
        conexion.query(query, (error, result) => {
            //return result;
            return res.status(200).json({ result: result });
        });
    } catch (error) {
        console.error('Error al seleccionar datos:', error);
        res.status(500).json({ error: "Error al traer listado" })
        throw error;
    }
}
exports.insertarConTransaccion = function (tabla, campos, listaDeValores, res) {
    try {
        conexion.beginTransaction(function (err) {
            if (err) {
                throw err;
            }

            const placeholders = campos.map(() => "?").join(", ");
            const consulta = `INSERT INTO ${tabla} (${campos.join(", ")}) VALUES (${placeholders})`;

            // Iterar sobre la lista de valores y ejecutar la consulta para cada conjunto de valores
            listaDeValores.forEach(valores => {
                conexion.query(consulta, valores, function (error, resultados) {
                    if (error) {
                        return conexion.rollback(function () {
                            throw error;
                        });
                    }
                });
            });

            // Si llegamos aquí, todos los inserts fueron exitosos, ahora commit la transacción
            conexion.commit(function (err) {
                if (err) {
                    return conexion.rollback(function () {
                        throw err;
                    });
                }

                res.status(200).json({ mensaje: "Datos insertados correctamente" });
            });
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
};

exports.insertarConTransaccionDetalle = function (tbl_principal, campos_principal, values_principal, tbl_secundaria, campoIdPrincipal, camposDetalle, listaDeValoresDetalle, res) {
    try {
        conexion.beginTransaction(function (err) {
            if (err) {
                throw err;
            }
            const placeholdersPrincipal = campos_principal.map(() => "?").join(", ");
            const consultaPrincipal = `INSERT INTO ${tbl_principal} (${campos_principal.join(", ")}) VALUES (${placeholdersPrincipal})`;
            console.log("consultaPrincipal: ", consultaPrincipal);

            conexion.query(consultaPrincipal, values_principal, function (errorPrincipal, resultadoPrincipal) {
                if (errorPrincipal) {
                    return conexion.rollback(function () {
                        throw errorPrincipal;
                    });
                }

                const principalId = resultadoPrincipal.insertId;

                // Crea los placeholders para cada fila en el detalle
                const placeholdersDetalle = listaDeValoresDetalle.map(() => `(${new Array(camposDetalle.length + 1).fill("?").join(", ")})`).join(", ");

                // Aplana los valores detalle y añade el ID principal a cada conjunto
                const camposValoresDetalle = Object.keys(listaDeValoresDetalle[0]);
                const valoresDetalle = listaDeValoresDetalle.flatMap(valores => [principalId, ...camposValoresDetalle.map(campo => valores[campo])]);

                const consultaDetalle = `INSERT INTO ${tbl_secundaria} (${[campoIdPrincipal, ...camposDetalle].join(", ")}) VALUES ${placeholdersDetalle}`;
                console.log("consultaDetalle: ", consultaDetalle);
                console.log("valoresDetalle: ", valoresDetalle);

                conexion.query(consultaDetalle, valoresDetalle, function (errorDetalle) {
                    if (errorDetalle) {
                        return conexion.rollback(function () {
                            throw errorDetalle;
                        });
                    }

                    // Si llegamos aquí, todos los inserts fueron exitosos, ahora commit la transacción
                    conexion.commit(function (errCommit) {
                        if (errCommit) {
                            return conexion.rollback(function () {
                                throw errCommit;
                            });
                        }

                        res.status(200).json({ mensaje: "Datos insertados correctamente" });
                    });
                });
            });
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
};

exports.insertarTransaccionConDetallesIDs = function (tablaPrincipal, tablaIds, tablaDetalle, camposPrincipal, camposDetalles, camposIdsABuscar, valoresPrincipal, valoresDetalle, valoresIds, campoIdDetalle, campoIdCondi, camposDetalleAux, campoNombre = '', idCampoNombre = '', res) {
    try {
        conexion.beginTransaction(function (err) {
            if (err) {
                console.log('Error al iniciar transaccion');
                throw err;
            }

            const placeholdersPrincipal = camposPrincipal.map(() => "?").join(", ");
            const query1 = `INSERT INTO ${tablaPrincipal} (${camposPrincipal.join(', ')}) VALUES (${placeholdersPrincipal})`;
            //const facturaValues = [datosFactura.num_factura, datosFactura.subtotal, datosFactura.iva, datosFactura.total];

            conexion.query(query1, valoresPrincipal, function (error, principalResult) {
                if (error) {
                    return conexion.rollback(function () {
                        throw error;
                    });
                }

                const principalId = principalResult.insertId;
                if (campoNombre?.length > 0) {
                    // Concatena el nombre con el ID
                    const nuevoNombre = valoresPrincipal[0] + (String(principalId).padStart(5, '0'));

                    // Actualiza el registro con el nuevo nombre
                    const updateQuery = `UPDATE ${tablaPrincipal} SET ${campoNombre} = ? WHERE ${idCampoNombre} = ?`;
                    conexion.query(updateQuery, [nuevoNombre, principalId], function (updateError, updateResult) {
                        if (updateError) {
                            return conexion.rollback(function () {
                                throw updateError;
                            });
                        }
                    });
                }

                valoresIds.forEach(idItem => {
                    // Realiza una búsqueda para obtener los detalles del producto
                    const query2 = `SELECT ${camposIdsABuscar.join(', ')} FROM ${tablaIds} WHERE ${campoIdCondi} = ?`;
                    conexion.query(query2, [idItem], function (errorDetalle, detalleResult) {
                        if (errorDetalle) {
                            return conexion.rollback(function () {
                                throw errorDetalle;
                            });
                        }

                        const detalleData = detalleResult[0];

                        const placeholdersDetalle = camposDetalles.map(() => "?").join(", ");
                        const detalleQuery = `INSERT INTO ${tablaDetalle} (${camposDetalles.join(', ')}) VALUES (${placeholdersDetalle})`;
                        const detalleValuesAux = valoresDetalle.find((objeto) => objeto[campoIdDetalle] === idItem);
                        const detalleValues = [principalId];
                        Object.keys(detalleValuesAux).forEach((key) => {
                            camposDetalleAux.forEach(namekeys => {
                                if (namekeys === key) {
                                    detalleValues.push(detalleValuesAux[namekeys]);
                                }
                            });
                        });
                        _.forEach(detalleData, function (valor) {
                            detalleValues.push(valor);
                        });

                        conexion.query(detalleQuery, detalleValues, function (errorDetalle, detalleResult) {
                            if (errorDetalle) {
                                return conexion.rollback(function () {
                                    throw errorDetalle;
                                });
                            }
                        });
                    });
                });

                conexion.commit(function (errCommit) {
                    if (errCommit) {
                        console.log('error al enviar commit');
                        return conexion.rollback(function () {
                            throw errCommit;
                        });
                    }

                    return res.status(200).json({ mensaje: "Factura y detalles insertados correctamente" });
                });

            });
        });
    } catch (error) {
        console.error("ERROR al tratar de insertar", error);
        return res.status(500).json({ error: "Error interno del servidor" });
    }
};

exports.buscarRegistro = function (tabla, campos, condicion, valor_condi, res) {
    try {
        const consulta = `SELECT ${campos.join(", ")} FROM ${tabla} WHERE ${condicion}`;
        console.log("buscarRegistro: ", consulta);
        conexion.query(consulta, [valor_condi], (error, resultados) => {
            if (error) {
                console.log(error);
                return res.status(400).json({ message: "Error en la consulta" });
            }
            console.log("resultado bsucarRegistro: ", resultados)

            if (resultados.length > 0) {
                const registro = resultados;
                return res.status(200).json({ result: registro });
            } else {
                return res.status(400).json({ mensaje: "Registro no encontrado" });
            }
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ mensaje: "Error del servidor" });
    }

};
exports.buscarRegistrosSecuencial = function (tabla, campos = [], condicion, valor_condi = [], res) {
    const consulta = `SELECT ${campos.join(", ")} FROM ${tabla} WHERE ${condicion}`;
    console.log("consulta buscarRegistros: ", consulta);
    conexion.query(consulta, valor_condi, (error, resultados) => {
        if (error) {
            console.log(error);
            return res.status(400).json({ message: "Error en la consulta" });
        }

        if (resultados.length > 0) {
            //const registro = resultados[0];
            return res.status(200).json({ data: resultados });
        } else {
            const secuencial = campos[1] === 'producto' ? 'PR0000000' : campos[1] === 'servicio' ? 'SV0000000' : 'CB0000000';
            return res.status(200).json({ data: [{ 'referencia': secuencial }] });
            //return res.status(400).json({ message: "Registro no encontrado" });
        }
    });
};
exports.buscarRegistros = function (tabla, campos = [], condicion, valor_condi = [], res) {
    const consulta = `SELECT ${campos.join(", ")} FROM ${tabla} WHERE ${condicion}`;
    console.log("consulta buscarRegistros: ", consulta);
    conexion.query(consulta, valor_condi, (error, resultados) => {
        if (error) {
            console.log(error);
            return res.status(400).json({ message: "Error en la consulta" });
        }

        if (resultados.length > 0) {
            //const registro = resultados[0];
            return res.status(200).json({ data: resultados });
        } else {
            return res.status(400).json({ message: "Registro no encontrado" });
        }
    });
};
exports.consultaGeneral = function (consulta, valores, callback) {
    console.log("consulta consultaGeneral: ", consulta);
    try {
        conexion.query(consulta, valores, (error, resultados) => {
            if (error) {
                console.log(error);
                callback(null, null);
            }
            if (resultados) {
                callback(null, resultados)
            } else {
                callback(null, null);
            }
        });
    } catch (error) {
        console.log(error);
    }

};
exports.consultaGeneralPromise = function (consulta, valores = []) {
    return new Promise((resolve, reject) => {
        conexion.query(consulta, valores, (error, resultados) => {
            //console.log(resultados);
            if (error) {
                console.log(error);
                return reject(error);
            }
            if (resultados?.length > 0) {
                resolve(resultados);
            } else {
                resolve([]);
            }
        });
    });
};
exports.consulta_sql_reportes = function (consulta, valores, callback) {
    //console.log("consulta consulta_sql_reportes: ", consulta);
    try {
        conexion.query(consulta, [valores], (error, resultados) => {
            if (error) {
                console.log(error);
                callback(null, null);
            }
            if (resultados?.length > 0) {
                callback(null, resultados)
            } else {
                callback(null, null);
            }
        });
    } catch (error) {
        console.log(error);
    }

}
