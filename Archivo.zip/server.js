const express = require('express');
const morgan = require("morgan");
var cors = require('cors')
const fileUpload = require("express-fileupload");
const backend_url = require('./constantes/backend_url');

var productosRuta = require('./rutas/productos/productos.rutas');
var usuariosRuta = require('./rutas/usuarios/usuarios.rutas');
var loginRuta = require('./rutas/autenticacion/login.rutas');
var categoriasRuta = require('./rutas/categorias/categorias.rutas');
var carritoRuta = require('./rutas/carrito/carrito.rutas');
var pedidosRuta = require('./rutas/pedidos/pedidos.rutas');
var dashboardRuta = require('./rutas/dashboard/dashboard.rutas');
var contactoRuta = require('./rutas/contacto/contacto.rutas');
const conexion = require('./database/db');


const app = express();
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
    cors({
        origin: "*",
        methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
        preflightContinue: false,
        optionsSuccessStatus: 204,
    })
);

app.use('/images_p', express.static('./product_img'))

//para procesar datos enviados desde forms
app.use(express.json());
app.use(express.urlencoded({ extended: true }))

app.use(fileUpload());

app.use('/login', loginRuta);
app.use('/categorias', categoriasRuta);
app.use('/carrito', carritoRuta);
app.use('/pedidos', pedidosRuta);
app.use('/productos', productosRuta);
app.use('/usuarios', usuariosRuta);
app.use('/dashboard', dashboardRuta);
app.use('/contacto', contactoRuta);

app.get('/usuarios/lista',(req, res)=>{
    conexion.query(`select * from vn_configuracion_usuarios;`,(err, result)=>{
        return res.status(200).json({result});
    })
})

//Para eliminar la cache 
app.use(function (req, res, next) {
    if (!req.user)
        res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    next();
});


app.listen(backend_url.backendPORT, () => {
    console.log('SERVIDOR INICIADO EN INSTANCIA - ' + backend_url.backendURL)
})