const express = require('express');
const router = express.Router();

const categoriasController = require('../../controladores/categorias/control_categorias')

router.route("/crear").post(categoriasController.crear_categoria)
router.route("/listar").get(categoriasController.listar_categorias)
router.route("/activar/:codigo").put(categoriasController.activar_categoria)
router.route("/eliminar/:codigo").delete(categoriasController.eliminar_categoria)
router.route("/actualizar/:codigo").put(categoriasController.actualizar_categoria)
router.route("/obtener/:codigo").get(categoriasController.getRegistro)
router.route("/combo").get(categoriasController.combo_categorias)


module.exports = router;
