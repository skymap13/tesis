const express = require('express');
const router = express.Router();

const dashboardController = require('../../controladores/dashboard/control_dashboard')

router.route("/:anio").get(dashboardController.data)


module.exports = router;
