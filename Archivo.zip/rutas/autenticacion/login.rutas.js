const express = require('express');
const router = express.Router();

const loginController = require('../../controladores/autenticacion/ctrl_autenticacion')

router.route("/").post(loginController.login)
router.route("/recuperarPass").post(loginController.recuperarContra)
router.route("/cmabiarPorRecup").put(loginController.cambiar_clave_por_recuperacion)
router.route("/validToken/:token").get(loginController.validToken);
router.route("/validTokenconfirm/:token").get(loginController.validTokenconfirm);
router.route("/cambiar_clave").put(loginController.cambiar_clave);


module.exports = router;
