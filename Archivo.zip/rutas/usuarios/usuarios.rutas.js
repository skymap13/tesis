const express = require('express');
const router = express.Router();

const usuariosController = require('../../controladores/usuarios/control_usuarios')

router.route("/crear").post(usuariosController.crear_usuarios)
router.route("/registrar").post(usuariosController.registrar_usuarios)
router.route("/listar").get(usuariosController.listar_usuarios)
router.route("/activar/:codigo").put(usuariosController.activar_usuarios)
router.route("/eliminar/:codigo").delete(usuariosController.eliminar_usuarios)
router.route("/actualizar/:codigo").put(usuariosController.actualizar_usuarios)
router.route("/actualizarInfoUser").put(usuariosController.actualizar_user_info)
router.route("/obtener/:codigo").get(usuariosController.getRegistro)
router.route("/combo").get(usuariosController.combo_usuarios)
router.route("/combo_perfiles").get(usuariosController.combo_perfiles)
router.route("/getid").get(usuariosController.obtenerId)
router.route("/cambiar_clave").put(usuariosController.cambiar_clave)

router.route("/enviarConfirmLink").post(usuariosController.enviar_correo_confirmacion);
router.route("/confirmLink").put(usuariosController.confirmacion_registro);


module.exports = router;
