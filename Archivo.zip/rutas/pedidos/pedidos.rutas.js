const express = require('express');
const router = express.Router();

const pedidosController = require('../../controladores/pedidos/control_pedidos')

router.route("/crear").post(pedidosController.crear_pedido)
router.route("/listar").get(pedidosController.listar_pedidos)
router.route("/activar/:codigo").put(pedidosController.activar)
router.route("/eliminar/:codigo").put(pedidosController.eliminar)
router.route("/actualizar/:codigo").put(pedidosController.actualizar)
router.route("/obtener/:codigo").get(pedidosController.getRegistro)
router.route("/combo").get(pedidosController.combo_pedidos)


module.exports = router;
