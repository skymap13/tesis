const express = require('express');
const router = express.Router();

const contactoController = require('../../controladores/contacto/control_contacto')

router.route("/enviarmensaje").post(contactoController.recibir_mensaje)
router.route("/listar").get(contactoController.listar_mensajes_contacto)
router.route("/obtener/:codigo").get(contactoController.getRegistro)


module.exports = router;
