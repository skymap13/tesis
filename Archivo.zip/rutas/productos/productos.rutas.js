const express = require('express');
const router = express.Router();

const productosController = require('../../controladores/productos/control_productos')

router.route("/crear").post(productosController.crear_producto)
router.route("/listar").get(productosController.listar_productos)
router.route("/infoforcart").get(productosController.info_cart_productos)
router.route("/infoforcarousel").get(productosController.listar_productos_carousel)
router.route("/activar/:codigo").put(productosController.activar_productos)
router.route("/eliminar/:codigo").delete(productosController.eliminar_productos)
router.route("/actualizar").put(productosController.actualizar_producto)
router.route("/obtener/:codigo").get(productosController.getRegistro)
router.route("/combo").get(productosController.combo_producto)


module.exports = router;
