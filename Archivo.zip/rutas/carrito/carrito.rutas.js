const express = require('express');
const router = express.Router();

const carritoController = require('../../controladores/carrito/control_carrito')

router.route("/agregardetalle").post(carritoController.agregar_al_carrito)
router.route("/listar").get(carritoController.listar_carrito)
router.route("/listar_cliente").get(carritoController.listar_carrito_cliente)
router.route("/obtener/:codigo").get(carritoController.getRegistro)
router.route("/eliminar/:codigo").delete(carritoController.eliminar_carrito)
router.route("/activar/:codigo").put(carritoController.activar_carrito)
router.route("/actualizar").put(carritoController.actualizar_carrito)


module.exports = router;
