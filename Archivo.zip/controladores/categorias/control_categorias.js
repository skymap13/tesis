const asyncHandler = require("express-async-handler");
const objSql = require("../../funciones/fSql");
const objFechaAuditoria = require("../../funciones/fFechas");
const objToken = require("../../funciones/fToken");
const objUsu = require("../../funciones/fUsuario");
const tabla = "vn_inventario_categorias";

var digitador = "SN";

const crear_categoria = asyncHandler(async (req, res) => {
  try {
    const { nombre, observacion } = req.body;
    let token = req.headers.token;
    let id_user = objToken.obtener_id_usuario(token);
    objUsu.obtenerDatosUser(id_user, async (err, datos_usuario) => {
      digitador = datos_usuario["USUA_NOMBRE"];
      var fecha_auditoria = objFechaAuditoria.fecha_hora_actual();
      let valores = [nombre, observacion !== undefined ? observacion : "", 'ACTIVO', digitador, fecha_auditoria];
      let campos = ["CATE_NOMBRE", "CATE_OBSERVACION", "CATE_ESTADO", "CATE_USUING", "CATE_FECING"];
      const camposUnicos = ["CATE_NOMBRE"];
      objSql.insertarSinRepetir(tabla, campos, valores, camposUnicos, res);

    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ mensaje: 'Error interno de servidor' });
  }

});

const listar_categorias = asyncHandler(async (req, res) => {
  try {
    const { page = 1, limit = 10, valorBusqueda } = req.query;
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = ['CATE_CODIGO as id', "CATE_NOMBRE as nombre", "CATE_OBSERVACION as observacion", "CATE_ESTADO as estado"];
      const campos_busqueda = ['CATE_CODIGO', 'CATE_NOMBRE', 'CATE_OBSERVACION', 'CATE_ESTADO']
      const condicion = ``;
      objSql.listarPaginacion(tabla, campos, campos_busqueda, page, valorBusqueda, limit, condicion, res)
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});

const activar_categoria = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'CATE_ESTADO': 'ACTIVO'
      }
      const condicion = `CATE_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al activar registro" })
  }
});

const eliminar_categoria = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'CATE_ESTADO': 'INACTIVO'
      }
      const condicion = `CATE_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al Eliminar registro" })
  }
});

const actualizar_categoria = asyncHandler(async (req, res) => {
  try {
    console.log('llego a actualizar_categoria')
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        if (datos_usuario) {
          const { nombre, observacion } = req.body;
          const camposValores = {
            "CATE_NOMBRE": nombre,
            "CATE_OBSERVACION": observacion,
            'CATE_USUING': datos_usuario.USUA_NOMBRE,
            'CATE_FECING': objFechaAuditoria.fecha_hora_actual(),
          }
          //eliminar campos con valor null o undefined
          Object.keys(camposValores).forEach(key => {
            if (camposValores[key] === null || camposValores[key] === undefined) {
              delete camposValores[key];
            }
          });
          const condicion = `CATE_CODIGO = ${req.params.codigo}`;
          objSql.actualizarDatos(tabla, camposValores, condicion, res);
        }
      })
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al actualizar los datos" })
  }
});

const getRegistro = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objSql.buscarRegistro(tabla, ['CATE_CODIGO as id', "CATE_NOMBRE as nombre", "CATE_OBSERVACION as observacion"], `CATE_CODIGO=?`, [req.params.codigo], res);

    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al buscar Usuario" })
  }
});

const combo_categorias = asyncHandler(async (req, res) => {
  try {
    let token = req.headers?.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = ['CATE_CODIGO as id', 'CATE_NOMBRE as nombre'];
      const condicion = 'CATE_ESTADO=?';
      const valores = ['ACTIVO']
      objSql.consultaGeneral(`SELECT ${campos.toString()} FROM ${tabla} WHERE ${condicion}`, valores, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).json({ error: "Error al buscar categorias" })
        } else {
          res.status(200).json({ result: result })
        }
      });

    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});

module.exports = {
  crear_categoria,
  listar_categorias,
  activar_categoria,
  eliminar_categoria,
  actualizar_categoria,
  getRegistro,
  combo_categorias
}