const asyncHandler = require("express-async-handler");
const objSql = require("../../funciones/fSql");
const objToken = require("../../funciones/fToken");
const objUsu = require("../../funciones/fUsuario");
const objFechaAuditoria = require("../../funciones/fFechas");
const objEncrip = require("../../funciones/fEncriptacion");
const tablaPrincipal = "vn_ventas_ordenes";
const tablaDetalle = "vn_ventas_ordenes_detalle";
var digitador = "DIGITADOR";

const crear_pedido = asyncHandler(async (req, res) => {
  try {
    const { product_list = [], total } = req.body;
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token);
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        digitador = datos_usuario["USUA_NOMBRE"];
        var id_carrito = datos_usuario["CARR_CODIGO"];
        var fecha_auditoria = objFechaAuditoria.fecha_hora_actual();
        const camposPrincipal = ['USUA_CODIGO', 'ORDE_TOTAL', 'ORDE_FECING']
        const valuesPrincipal = [id_usuario, total, fecha_auditoria]
        const camposDetalle = ['PROD_CODIGO', 'ORDET_CANTIDAD', 'ORDET_PRECIO', 'ORDET_FECING']
        const valuesDetalle = product_list.map(({ id_producto, cantidad, total }) => ({
          id_producto,
          cantidad,
          total,
          fecha_auditoria
        }));
        const campoIdPrincipal = 'ORDE_CODIGO';
        objSql.consultaGeneral(`SELECT CARR_CODIGO FROM vn_ventas_carrito WHERE USUA_CODIGO=?`, [id_usuario], (err, resultCarr) => {
          console.log('resultCarr:', resultCarr);
          objSql.consultaGeneral(`DELETE FROM vn_ventas_carrito_detalle WHERE CARR_CODIGO=?;`, [resultCarr[0]?.CARR_CODIGO], (err, result) => {
            if (err) {
              return res.status(500).json({ mensaje: 'No se pudo borrar el carrito de compras' })
            }
            console.log('result:', result);
            objSql.insertarConTransaccionDetalle(tablaPrincipal, camposPrincipal, valuesPrincipal, tablaDetalle, campoIdPrincipal, camposDetalle, valuesDetalle, res)
          });
        });
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'Error al crear usuario' });
  }

});

const listar_pedidos = asyncHandler(async (req, res) => {
  try {
    const { page = 1, limit = 10, valorBusqueda } = req.query;
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = [
        'ORDE_CODIGO as id',
        'vn_configuracion_usuarios.USUA_NOMBRE as nombre_usuario',
        'ORDE_FECING as fecha_ingreso',
        'ORDE_TOTAL as total'
      ];
      const campos_busqueda = ['ORDE_CODIGO', 'vn_configuracion_usuarios.USUA_NOMBRE', 'ORDE_FECING', 'ORDE_TOTAL'];
      objSql.listarPaginacionRelaciones(tablaPrincipal, campos, campos_busqueda, page, valorBusqueda, limit, res, 'vn_configuracion_usuarios', `${tablaPrincipal}.USUA_CODIGO`, 'vn_configuracion_usuarios.USUA_CODIGO');
    } else {
      console.log('No se encontró el ID del usuario');
      res.status(500).json({ error: "No se encontró el ID del usuario" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" });
  }
});


const activar = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.authorization || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'PEDI_ESTADO': 'ACTIVO'
      }
      const condicion = `PEDI_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al activar registro" })
  }
});

const eliminar = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.authorization || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'PEDI_ESTADO': 'INACTIVO'
      }
      const condicion = `PEDI_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al Eliminar registro" })
  }
});

const anular = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.authorization || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'PEDI_ESTADO': 'ANULADO'
      }
      const condicion = `PEDI_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al Eliminar registro" })
  }
});

const entregado = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.authorization || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'PEDI_ESTADO': 'ENTREGADO'
      }
      const condicion = `PEDI_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al Eliminar registro" })
  }
});

const pendiente = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.authorization || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'PEDI_ESTADO': 'PENDIENTE'
      }
      const condicion = `PEDI_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al Eliminar registro" })
  }
});

const actualizar = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.authorization || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const datos_usuario = await objUsu.consultaDatosUsuario(id_usuario);
      const { codigo_pedido, detalle_pedido, estado_pedido, fecha_hora_entrega, direccion_pedido, info_pago } = req.body;
      const camposValores = {
        'PEDI_CODXX': codigo_pedido,
        'PEDI_DETALLE': detalle_pedido,
        'PEDI_ESTADO': estado_pedido,
        'PEDI_FECENTREGA': fecha_hora_entrega,
        'PEDI_DIRECC': direccion_pedido,
        'PEDI_INFPAGO': info_pago,
        'PEDI_USUING': datos_usuario.USUA_NOMBRE,
        'PEDI_FECING': objFechaAuditoria.fecha_hora_actual(),
      }
      const condicion = `PEDI_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al actualizar los datos" })
  }
});

const getRegistro = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    console.log(token)
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    console.log(id_usuario)
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        objSql.consultaGeneral(`SELECT 
          ordet.ORDET_CODIGO as id,
          prod.PROD_NOMBRE as nombre_producto,
          ordet.ORDET_PRECIO as precio,
          ordet.ORDET_CANTIDAD as cantidad
          FROM vn_ventas_ordenes_detalle as ordet
          INNER JOIN vn_inventario_productos prod ON prod.PROD_CODIGO=ordet.PROD_CODIGO
          WHERE ORDE_CODIGO=?`, [req.params.codigo], (err, result) => {
          if (err) {
            console.log("error en la consulta:", err);
            return res.status(500).json({ result: null, mensaje: 'Error en la consulta' })
          }
          return res.status(200).json({ result: result, mensaje: 'Datos obtenidos' });
        })
      });
    } else {
      console.log('No se encontro el ID del usuario')
      return res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Error al buscar Usuario" })
  }
});

const combo_pedidos = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.authorization || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = ['PEDI_CODIGO as id', 'PEDI_DETALLE as nombre'];
      const condicion = 'PEDI_ESTADO=?';
      const valores = ['ACTIVO']
      objSql.comboGeneral(tabla, campos, condicion, valores, res);

    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});

module.exports = {
  crear_pedido,
  listar_pedidos,
  eliminar,
  actualizar,
  getRegistro,
  activar,
  anular,
  entregado,
  pendiente,
  combo_pedidos
};
