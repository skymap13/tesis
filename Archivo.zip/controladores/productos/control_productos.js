const asyncHandler = require("express-async-handler");
const objSql = require("../../funciones/fSql");
const objFechaAuditoria = require("../../funciones/fFechas");
const objToken = require("../../funciones/fToken");
const objUsu = require("../../funciones/fUsuario");
const tabla = "vn_inventario_productos";
const objClaveAle = require('../../funciones/fClaveAleatoria');
const path = require("path");
const e = require("express");
const fs = require('fs');

var digitador = "SN";

const crear_producto = asyncHandler(async (req, res) => {
  try {
    const { nombre, id_categoria, observacion, codigoP, precio } = req.body;
    const file = req.files?.file || null;
    let token = req.headers?.token || null;
    if (token) {
      let id_user = objToken.obtener_id_usuario(token);
      objUsu.obtenerDatosUser(id_user, async (err, datos_usuario) => {
        if (datos_usuario) {
          var digitador = datos_usuario["USUA_NOMBRE"];
          var fecha_auditoria = objFechaAuditoria.fecha_hora_actual();

          const newpath = path.join(__dirname, `../../product_img/`);
          console.log("newpath", newpath);
          const auxFileName = objClaveAle.randomico(32, 2) + (file.name.replaceAll(" ", ""));
          if (file) {
            file.mv(`${newpath}${auxFileName}`, (err) => {
              if (err) {
                console.log(err);
                res.status(500).json({ message: "Error al subir la imagen" })
              }
              else console.log("Imagen subida...!!!");
            });
            let valores = [nombre, id_categoria, codigoP, observacion !== undefined ? observacion : "", auxFileName, precio, 'ACTIVO', digitador, fecha_auditoria];
            let campos = ["PROD_NOMBRE", "CATE_CODIGO", "PROD_CODEXX", "PROD_OBSERVACION", "PROD_IMGNAME", "PROD_PRECIO", "PROD_ESTADO", "PROD_USUING", "PROD_FECING"];
            const camposUnicos = ["PROD_NOMBRE", "PROD_CODEXX"];
            objSql.insertarSinRepetir(tabla, campos, valores, camposUnicos, res);
          }

        }
      });
    } else {
      return res.status(500).json({ mensaje: 'No se recibio el token' });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ mensaje: 'Error interno' });
  }

});

const listar_productos = asyncHandler(async (req, res) => {
  try {
    const { page = 1, limit = 10, valorBusqueda } = req.query;
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = ['PROD_CODIGO as id', "PROD_NOMBRE as nombre", "CATE_CODIGO as id_categoria", "PROD_CODEXX as codigox", "PROD_OBSERVACION as observacion", "PROD_PRECIO as precio", "PROD_ESTADO as estado"];
      const campos_busqueda = ['PROD_NOMBRE', 'PROD_CODEXX', 'PROD_OBSERVACION', 'PROD_ESTADO'];
      const condicion = ``;
      objSql.listarPaginacion(tabla, campos, campos_busqueda, page, valorBusqueda, limit, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});
const listar_productos_carousel = asyncHandler(async (req, res) => {
  try {
    const { page = 1, limit = 3, valorBusqueda } = req.query;
    const campos = ['PROD_CODIGO as id', "PROD_NOMBRE as nombre", "CATE_CODIGO as id_categoria", "PROD_CODEXX as codigox", "PROD_OBSERVACION as observacion", "PROD_PRECIO as precio", "PROD_ESTADO as estado"];
    const campos_busqueda = ['PROD_NOMBRE', 'PROD_CODEXX', 'PROD_OBSERVACION', 'PROD_ESTADO'];
    const condicion = ``;
    objSql.listarPaginacion(tabla, campos, campos_busqueda, page, valorBusqueda, limit, condicion, res);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado para carousel" });
  }
});
const info_cart_productos = asyncHandler(async (req, res) => {
  try {
    const { page = 1, limit = 3, valorBusqueda } = req.query;
    const campos = ['PROD_CODIGO as id', "PROD_NOMBRE as nombre", "CATE_CODIGO as id_categoria", "PROD_CODEXX as codigox", "PROD_OBSERVACION as observacion", "PROD_ESTADO as estado", "PROD_IMGNAME as imagen", "PROD_PRECIO as precio"];
    const campos_busqueda = ['PROD_NOMBRE', 'PROD_CODEXX', 'PROD_OBSERVACION', 'PROD_ESTADO']
    const condicion = ` AND PROD_ESTADO='ACTIVO'`
    objSql.listarPaginacion(tabla, campos, campos_busqueda, page, valorBusqueda, limit, condicion, res)
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});

const activar_productos = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'PROD_ESTADO': 'ACTIVO'
      }
      const condicion = `PROD_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al activar registro" })
  }
});

const eliminar_productos = asyncHandler(async (req, res) => {
  try {
    console.log(req);
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'PROD_ESTADO': 'INACTIVO'
      }
      const condicion = `PROD_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al Eliminar registro" })
  }
});

const actualizar_producto = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        if (datos_usuario) {
          const { nombre, id_categoria, codigoP, precio, observacion, id } = req.body;
          const file = req.files?.file || null;
          const newpath = path.join(__dirname, `../../product_img/`);
          var auxFileName = '';

          const camposValores = {
            "PROD_NOMBRE": nombre,
            "CATE_CODIGO": id_categoria,
            "PROD_CODEXX": codigoP,
            "PROD_OBSERVACION": observacion,
            "PROD_PRECIO": precio,
            'PROD_USUMOD': datos_usuario.USUA_NOMBRE,
            'PROD_FECMOD': objFechaAuditoria.fecha_hora_actual(),
          };
          //Proceso de borrado de imagen, si, le mandamos un archivo nuevo
          if (file) {
            objSql.consultaGeneral(`SELECT PROD_IMGNAME FROM ${tabla} WHERE PROD_CODIGO=?;`, [id], (err, resultImgName) => {
              console.log(resultImgName);
              var imagenActual = resultImgName[0]?.PROD_IMGNAME || null;

              console.log("newpath:", newpath);
              if (imagenActual) {
                const oldImagePath = path.join(newpath, imagenActual);
                fs.unlink(oldImagePath, (err) => {
                  if (err) {
                    console.log(`Error al eliminar la imagen anterior: ${imagenActual}`, err);
                  } else {
                    console.log(`Imagen anterior eliminada: ${imagenActual}`);
                    auxFileName = objClaveAle.randomico(32, 2) + (file.name.replaceAll(" ", ""));
                    console.log("imagen nueva: ", auxFileName)
                    file.mv(`${newpath}${auxFileName}`, (err) => {
                      if (err) {
                        console.log(err);
                        res.status(500).json({ message: "Error al subir la imagen" })
                      }
                      else {
                        console.log("Imagen subida...!!!");
                        camposValores.PROD_IMGNAME = auxFileName;
                        //eliminar campos con valor null o undefined
                        console.log('camposValores:', camposValores);
                        Object.keys(camposValores).forEach(key => {
                          if (camposValores[key] === null || camposValores[key] === undefined) {
                            delete camposValores[key];
                          }
                        });

                        const condicion = `PROD_CODIGO = ${id}`;
                        objSql.actualizarDatos(tabla, camposValores, condicion, res);
                      }
                    });
                  }
                });
              }

            });
          } else {
            console.log('camposValores:', camposValores);
            Object.keys(camposValores).forEach(key => {
              if (camposValores[key] === null || camposValores[key] === undefined) {
                delete camposValores[key];
              }
            });

            const condicion = `PROD_CODIGO = ${id}`;
            objSql.actualizarDatos(tabla, camposValores, condicion, res);
          }
        } else {
          res.status(500).json({ error: "Datos del usuario no encontrados" });
        }
      });
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al actualizar los datos" })
  }
});


const getRegistro = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objSql.buscarRegistro(tabla, ['PROD_CODIGO as id', "PROD_NOMBRE as nombre", "CATE_CODIGO as id_categoria", "PROD_CODEXX as codigox", "PROD_OBSERVACION as observacion", "PROD_PRECIO as precio"], `PROD_CODIGO=${req.params.codigo}`, [req.params.codigo], res);

    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al buscar Usuario" })
  }
});

const combo_producto = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        const campos = ['PROD_CODIGO as id', 'PROD_NOMBRE as nombre'];
        const condicion = 'PROD_ESTADO=?';
        const valores = ['ACTIVO']
        objSql.consultaGeneral(`SELECT ${campos.join(', ')} FROM ${tabla} WHERE ${condicion};`, valores, (err, result) => {
          if (err) {
            console.log(err);
            res.status(500).json({ error: "Error al obtener los productos" });
          } else {
            return res.status(200).json({ result });
          }
        });
      })
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});

module.exports = {
  crear_producto,
  listar_productos,
  activar_productos,
  eliminar_productos,
  actualizar_producto,
  getRegistro,
  combo_producto,
  info_cart_productos,
  listar_productos_carousel
}