const asyncHandler = require("express-async-handler");
const objSql = require("../../funciones/fSql");
const objFechaAuditoria = require("../../funciones/fFechas");
const objToken = require("../../funciones/fToken");
const objUsu = require("../../funciones/fUsuario");
const tablaPrincipal = "vn_ventas_carrito";
const tablaDetalle = "vn_ventas_carrito_detalle";
const tablaProductos = "vn_inventario_productos";

var digitador = "SN";

const agregar_al_carrito = asyncHandler(async (req, res) => {
  const { id_producto, cantidad } = req.body;
  console.log(req.body);
  let token = req.headers.token;
  let id_user = objToken.obtener_id_usuario(token);
  objUsu.obtenerDatosUser(id_user, async (err, datos_usuario) => {
    if (datos_usuario) {
      digitador = datos_usuario["USUA_NOMBRE"];
      var fecha_auditoria = objFechaAuditoria.fecha_hora_actual();
      objSql.consultaGeneral(`SELECT CARR_CODIGO FROM ${tablaPrincipal} WHERE USUA_CODIGO=?`, [id_user], (err, resultCarrito) => {
        console.log('resultCarrito:', resultCarrito);
        if (resultCarrito) {
          objSql.consultaGeneral(`SELECT PROD_CODIGO FROM ${tablaProductos} WHERE PROD_CODIGO=?`, [id_producto], (err, resultProducto) => {
            console.log('resultProducto:', resultProducto);
            if (resultProducto) {
              let valores = [resultCarrito[0].CARR_CODIGO, resultProducto[0].PROD_CODIGO, cantidad, fecha_auditoria];
              let campos = ["CARR_CODIGO", "PROD_CODIGO", "CADE_CANTIDAD", "CADE_FECING"];
              objSql.insertar(tablaDetalle, campos, valores, res, 'Se añadio al carrito');
            }
          });
        }
      });
    }
  });
});

const listar_carrito_cliente = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
      if (datos_usuario) {
        const campos = ['cade.CADE_CODIGO as id', "carr.CARR_CODIGO as id_carrito", "prod.PROD_CODIGO as id_producto", "prod.PROD_NOMBRE as nombre", "prod.PROD_PRECIO as precio", "prod.PROD_IMGNAME as imagenpath", "cade.CADE_CANTIDAD as cantidad"];
        objSql.consultaGeneral(`SELECT ${campos.join(', ')} from ${tablaDetalle} as cade
          INNER JOIN ${tablaPrincipal} carr ON carr.CARR_CODIGO=cade.CARR_CODIGO
          INNER JOIN ${tablaProductos} prod ON prod.PROD_CODIGO=cade.PROD_CODIGO
          WHERE carr.USUA_CODIGO=?`, [datos_usuario.USUA_CODIGO], (err, resultDetalles) => {
          if (resultDetalles) {
            // Procesar los datos para agrupar por id_producto
            const productosAgrupados = resultDetalles.reduce((acc, item) => {
              const { id, id_producto, nombre, precio, imagenpath, cantidad } = item;
              if (!acc[id_producto]) {
                acc[id_producto] = {
                  id,
                  id_producto,
                  nombre,
                  precio: parseFloat(precio),
                  imagenpath,
                  cantidad: parseInt(cantidad),
                  total: parseFloat(precio) * parseInt(cantidad)
                };
              } else {
                acc[id_producto].cantidad += parseInt(cantidad);
                acc[id_producto].total += parseFloat(precio) * parseInt(cantidad);
              }
              return acc;
            }, {});

            const resultadoFinal = Object.values(productosAgrupados);

            return res.status(200).json({ result: resultadoFinal });
          } else {
            return res.status(400).json({ result: [], mensaje: 'No se encontraron datos para el carrito' });
          }
        });
      } else {
        console.log('No se encontró el ID del usuario');
        res.status(500).json({ error: "No se encontró el ID del usuario" });
      }
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" });
  }
});

const listar_carrito = asyncHandler(async (req, res) => {
  try {
    const { page = 1, limit = 10, valorBusqueda } = req.query;
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = [
        'CARR_CODIGO as id',
        'vn_configuracion_usuarios.USUA_NOMBRE as nombre_usuario',
        'CARR_FECING as fecha_ingreso',
        'CARR_ESTADO as estado'
      ];
      const campos_busqueda = ['CARR_CODIGO', 'vn_configuracion_usuarios.USUA_NOMBRE', 'CARR_FECING', 'CARR_ESTADO'];
      objSql.listarPaginacionRelaciones(tablaPrincipal, campos, campos_busqueda, page, valorBusqueda, limit, res, 'vn_configuracion_usuarios', `${tablaPrincipal}.USUA_CODIGO`, 'vn_configuracion_usuarios.USUA_CODIGO');
    } else {
      console.log('No se encontró el ID del usuario');
      res.status(500).json({ error: "No se encontró el ID del usuario" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" });
  }
});


const activar_carrito = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'CARR_ESTADO': 'ACTIVO'
      }
      const condicion = `CARR_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tablaPrincipal, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al activar registro" })
  }
});
const actualizar_carrito = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objSql.consultaGeneral(`SELECT CARR_CODIGO FROM ${tablaPrincipal} WHERE USUA_CODIGO=?`, [id_usuario], (err, result) => {
        const camposActualizar = ['CADE_CANTIDAD'];
        const listaItems = req.body ||req?.body?.result; 
        console.log(listaItems)
        const listaItemsFiltrada = listaItems.map(({ id, cantidad }) => ({ id, cantidad }));
        const condicion = `WHERE CADE_CODIGO = ?`;
        console.log('listaItemsFiltrada:', listaItemsFiltrada)
        objSql.actualizarVariosDatos(tablaDetalle, camposActualizar, listaItemsFiltrada, condicion, res);
      });
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al activar registro" })
  }
});

const eliminar_carrito = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'CARR_ESTADO': 'INACTIVO'
      }
      const condicion = `CARR_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tablaPrincipal, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al Eliminar registro" })
  }
});

const eliminarProductoCarrito = asyncHandler(async (req, res) => {
  const { id } = req.body;
  const token = req.headers.token;
  const id_usuario = objToken.obtener_id_usuario(token);

  if (id_usuario) {
    objSql.consultaGeneral(`SELECT CARR_CODIGO FROM ${tablaPrincipal} WHERE USUA_CODIGO = ?`, [id_usuario], (err, result) => {
      if (err) {
        res.status(500).json({ error: "Error al obtener el código del carrito" });
        return;
      }

      const carritoCodigo = result[0]?.CARR_CODIGO;

      objSql.consultaGeneral(`DELETE FROM ${tablaDetalle} WHERE CADE_CODIGO = ? AND CARR_CODIGO = ?`, [id, carritoCodigo], (err, result) => {
        if (err) {
          res.status(500).json({ error: "Error al eliminar el producto del carrito" });
          return;
        }

        res.status(200).json({ success: true, mensaje: "Producto eliminado del carrito" });
      });
    });
  } else {
    res.status(401).json({ error: "Usuario no autorizado" });
  }
});

const getRegistro = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        if (datos_usuario) {
          objSql.consultaGeneral(`SELECT 
            card.CADE_CODIGO as id,
            card.CARR_CODIGO as id_carrito,
            prod.PROD_NOMBRE as nombre_producto,
            card.CADE_CANTIDAD as cantidad
            FROM ${tablaDetalle} as card
            INNER JOIN ${tablaProductos} prod ON prod.PROD_CODIGO=card.PROD_CODIGO
            WHERE card.CARR_CODIGO=?`, [req.params.codigo], (err, result) => {
            if (err) {
              console.log("error en la consulta:", err);
              return res.status(500).json({ result: null, mensaje: 'Error en la consulta' })
            }
            return res.status(200).json({ result: result, mensaje: 'Datos obtenidos' });
          })
        }
      });
    } else {
      console.log('No se encontro el ID del usuario')
      return res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Error al buscar Usuario" })
  }
});

module.exports = {
  agregar_al_carrito,
  listar_carrito,
  listar_carrito_cliente,
  activar_carrito,
  actualizar_carrito,
  eliminar_carrito,
  eliminarProductoCarrito,
  getRegistro
}