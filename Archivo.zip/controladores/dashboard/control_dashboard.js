const asyncHandler = require("express-async-handler");
const objSql = require("../../funciones/fSql");
const objFechaAuditoria = require("../../funciones/fFechas");
const objToken = require("../../funciones/fToken");
const objUsu = require("../../funciones/fUsuario");
const tabla = "vn_inventario_categorias";

var digitador = "SN";


const data = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    const { anio } = req.params;
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, async (err, datos_usuario) => {
        if (datos_usuario) {
          const [productos] = await objSql.consultaGeneralPromise(`SELECT COUNT(*) AS cant_productos FROM vn_inventario_productos;`);
          const [pedidos] = await objSql.consultaGeneralPromise(`SELECT COUNT(*) AS cant_pedidos FROM vn_ventas_carrito;`);
          const [carritos] = await objSql.consultaGeneralPromise(`SELECT COUNT(*) AS cant_carritos FROM vn_ventas_ordenes;`);
          const ventas = await objSql.consultaGeneralPromise(`
            SELECT 
              DATE_FORMAT(ORDET_FECING, '%Y-%m') AS mes,
              SUM(ORDET_CANTIDAD) AS result
            FROM 
              vn_ventas_ordenes_detalle
            WHERE 
              YEAR(ORDET_FECING) = ?
            GROUP BY 
              DATE_FORMAT(ORDET_FECING, '%Y-%m')
            ORDER BY 
              mes;`,[anio]);
          const ingresos = await objSql.consultaGeneralPromise(`
            SELECT 
              DATE_FORMAT(ORDET_FECING, '%Y-%m') AS mes,
              SUM(ORDET_PRECIO) AS result
            FROM 
              vn_ventas_ordenes_detalle
            WHERE 
              YEAR(ORDET_FECING) = ?
            GROUP BY 
              DATE_FORMAT(ORDET_FECING, '%Y-%m')
            ORDER BY 
              mes;`,[anio]);
          //console.log(ventas);
          console.log({
            cant_productos: productos.cant_productos,
            cant_pedidos: pedidos.cant_pedidos,
            cant_carritos: carritos.cant_carritos,
            info_ventas: ventas,
            ingresos: ingresos
          });
          return res.status(200).json({
            result: {
              cant_productos: productos.cant_productos,
              cant_pedidos: pedidos.cant_pedidos,
              cant_carritos: carritos.cant_carritos,
              info_ventas: ventas,
              ingresos: ingresos
            },
            mensaje: 'Datos para dashboard, cargados'
          });
        }
      });
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});

module.exports = {
  data
}