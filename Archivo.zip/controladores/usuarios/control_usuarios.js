const asyncHandler = require("express-async-handler");
const objSql = require("../../funciones/fSql");
const objFechaAuditoria = require("../../funciones/fFechas");
const objToken = require("../../funciones/fToken");
const objUsu = require("../../funciones/fUsuario");
const tabla = "vn_configuracion_usuarios";
const tablaPerfiles = "vn_configuracion_perfil";
const objEncrip = require('../../funciones/fEncriptacion');
const objClave = require('../../funciones/fClaveAleatoria');
const objCorreo = require("../../funciones/fCorreo");
const url = require('../../constantes/frontend_url');
const objFechas = require('../../funciones/fFechas');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment-timezone');

var digitador = "SN";

const crear_usuarios = asyncHandler(async (req, res) => {
  const { nombre, apellido, celular, correo, id_perfil, observacion } = req.body;
  console.log("Body: ", req.body);
  let token = req.headers.token;
  if (token) {
    let id_user = objToken.obtener_id_usuario(token);
    objUsu.obtenerDatosUser(id_user, async (err, datos_usuario) => {
      if (datos_usuario) {
        digitador = datos_usuario["USUA_NOMBRE"];
        var fecha_auditoria = objFechaAuditoria.fecha_hora_actual();
        var clave = objClave.randomico(10, 3).toString();
        let valores = [clave, nombre, apellido, celular, correo, observacion !== undefined ? observacion : "", id_perfil, 'ACTIVO', fecha_auditoria, digitador];
        let campos = ["USUA_CLAVE", "USUA_NOMBRE", "USUA_APELLIDO", "USUA_CELULAR", "USUA_CORREO", "USUA_OBSERVACION", "PERF_CODIGO", "USUA_ESTADO", "USUA_FECING", "USUA_USUING"];
        objSql.consultaGeneral(`SELECT * FROM ${tabla} WHERE USUA_CORREO=?`, [correo], (err, result) => {
          if (err) throw err;
          if (result.length > 0) {
            res.status(400).json({ message: "Ya existe un usuario con esa cedula" });
          } else {
            var html = `Hola,<br><br>Nombre: ${nombre}<br><br>Apellidos: ${apellido}<br><br>Correo:${correo}<br><br>Use esta clave para acceder a Vernelly Detalles. La clave es la siguiente:<br><br><a>${clave}</a><br><br>Saludos,`
            var asunto = "VERNNELLY DETALLES: Bienvenido!!";
            objCorreo.enviar_correo_html(correo, asunto, html);
            objSql.insertarConTransaccionDetalle(tabla, campos, valores, 'vn_ventas_carrito', 'USUA_CODIGO', ['CARR_FECING', 'CARR_ESTADO'], [[fecha_auditoria, 'ACTIVO']], res)
          }
        });
      }
    });
  }
});

const registrar_usuarios = asyncHandler(async (req, res) => {
  const { nombre, apellido, correo, password, celular } = req.body;
  console.log("Body: ", req.body);
  var clave_encrip = objEncrip.encriptar_sha512(password.toString());
  var fecha_auditoria = objFechaAuditoria.fecha_hora_actual();
  let valores = [nombre, apellido, correo, 31, celular, clave_encrip, 'INACTIVO', fecha_auditoria, digitador];
  let campos = ["USUA_NOMBRE", "USUA_APELLIDO", "USUA_CORREO", "PERF_CODIGO", "USUA_CELULAR", "USUA_CLAVE", "USUA_ESTADO", "USUA_FECING", "USUA_USUING"];
  objSql.consultaGeneral(`SELECT * FROM ${tabla} WHERE USUA_CORREO=?`, [correo], (err, result) => {
    if (err) throw err;
    if (result?.length > 0) {
      res.status(400).json({ mensaje: "Ya existe un usuario con ese correo" });
    } else {
      objSql.insertarConTransaccionDetalle(tabla, campos, valores, 'vn_ventas_carrito', 'USUA_CODIGO', ['CARR_FECING', 'CARR_ESTADO'], [[fecha_auditoria, 'ACTIVO']], res)
    }
  });
});
const enviar_correo_confirmacion = asyncHandler(async (req, res) => {
  const { correo } = req.body;
  console.log("Body: ", req.body);
  const token = uuidv4();
  var expirationDate = moment().tz('America/Guayaquil');
  expirationDate = expirationDate.add(5, 'minutes');
  const formattedExpirationDate = expirationDate.format('YYYY-MM-DD HH:mm:ss');
  console.log(formattedExpirationDate);
  var destinatario = correo;

  objSql.consultaGeneral(`SELECT * FROM ${tabla} WHERE USUA_CORREO=?`, [correo], (err, result) => {
    if (err) throw err;
    if (result?.length > 0) {
      const confirmLink = `${url.frontendURL}/confirmar_registro/${token}`;
      var asunto = "VERNNELLY DETALLES: Confirmacion de registro";
      var html = `Hola,<br><br>Se ha registrado en Vernelly Detalles. Haz clic en el siguiente enlace para confirmar tu registro y activar tu cuenta:<br><br><a href="${confirmLink}">Confirmar</a><br><br>Bienvenido a Vernelly Detalles.`
      var cadenasql = `UPDATE ${tabla} SET USUA_TOKENCONFIRM = ?, USUA_TOKDATCONFIRM = ? WHERE USUA_CORREO = ?`;
      const valoresTokenConfirm = [token, formattedExpirationDate, correo];
      objSql.consultaGeneral(cadenasql, valoresTokenConfirm, (err, result) => {
        if (err) {
          console.log('Error en la consulta: ', err);
          return res.status(500).json({ mensaje: 'Error en la consulta' });
        } else if (result?.affectedRows > 0) {
          objCorreo.enviar_correo_html_recup_password(destinatario, asunto, html, token, res);
          //return res.status(200).json({ mensaje: 'Se envio un correo para confirmar la cuenta' });
        }
      })
    } else {
      console.log('no se encontro el correo del usuario registrado');
      res.status(400).json({ mensaje: "No se encontro el correo de usuario registrado" });
    }
  });
});

const confirmacion_registro = asyncHandler(async (req, res) => {
  try {
    var { token } = req.body;
    objSql.consultaGeneral(`SELECT USUA_TOKENCONFIRM, USUA_TOKDATCONFIRM FROM ${tabla} WHERE USUA_TOKENCONFIRM=?`, [token], (err, result) => {
      var fecha_actual = objFechas.fecha_hora_actual_NOFORMAT();
      var validDate = objFechas.compararFechas(result[0].USUA_TOKDATCONFIRM, fecha_actual);
      if (validDate) {
        const camposValores = {
          'USUA_ESTADO': 'ACTIVO'
        }
        const condicion = `USUA_TOKENCONFIRM='${token}'`;
        objSql.actualizarDatos(tabla, camposValores, condicion, res);
      } else {
        return res.status(401).json({ mensaje: "Tiempo expirado" })
      }
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al buscar Usuario" })
  }
});

const listar_usuarios = asyncHandler(async (req, res) => {
  try {
    const { page = 1, limit = 10, valorBusqueda } = req.query;
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = ["USUA_CODIGO as id",
        "USUA_NOMBRE as nombre",
        "USUA_APELLIDO as apellido",
        "USUA_CELULAR as celular",
        "USUA_CORREO as correo",
        "USUA_DIRECCION as direccion",
        "USUA_OBSERVACION as observacion",
        "USUA_ESTADO as estado"];
      const campos_busqueda = ["USUA_NOMBRE", "USUA_APELLIDO", "USUA_CELULAR", "USUA_CORREO", "USUA_DIRECCION", "USUA_OBSERVACION", "USUA_ESTADO"]
      const condicion = ``;
      objSql.listarPaginacion(tabla, campos, campos_busqueda, page, valorBusqueda, limit, condicion, res)
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});

const activar_usuarios = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'USUA_ESTADO': 'ACTIVO'
      }
      const condicion = `USUA_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al activar registro" })
  }
});

const eliminar_usuarios = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const camposValores = {
        'USUA_ESTADO': 'INACTIVO'
      }
      const condicion = `USUA_CODIGO = ${req.params.codigo}`;
      objSql.actualizarDatos(tabla, camposValores, condicion, res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al Eliminar registro" })
  }
});

const actualizar_usuarios = asyncHandler(async (req, res) => {
  try {
    let token = req?.headers?.token || null;
    let idItem = req?.params?.codigo || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        const { nombre, apellido, observacion, celular, correo, id_perfil } = req.body;
        const camposValores = {
          "USUA_NOMBRE": nombre,
          "USUA_APELLIDO": apellido,
          "USUA_CELULAR": celular,
          "USUA_CORREO": correo,
          "USUA_OBSERVACION": observacion,
          "PERF_CODIGO": id_perfil,
          'USUA_USUING': datos_usuario.USUA_NOMBRE,
          'USUA_FECING': objFechaAuditoria.fecha_hora_actual(),
        }
        const condicion = `USUA_CODIGO = ${idItem}`;
        objSql.actualizarDatos(tabla, camposValores, condicion, res);

      });
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al actualizar los datos" })
  }
});

const actualizar_user_info = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      //const datos_usuario = await objUsu.obtenerDatosUser(id_usuario);
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        if (!err) {
          const { nombre,
            apellido,
            celular,
            direccion } = req.body;
          const camposValores = {
            "USUA_NOMBRE": nombre,
            "USUA_APELLIDO": apellido,
            "USUA_CELULAR": celular,
            "USUA_DIRECCION": direccion,
            'USUA_USUMOD': datos_usuario.USUA_NOMBRE,
            'USUA_FECMOD': objFechaAuditoria.fecha_hora_actual(),
          }
          console.log('camposValores:', camposValores);
          Object.keys(camposValores).forEach(key => {
            if (camposValores[key] === null || camposValores[key] === undefined) {
              delete camposValores[key];
            }
          });
          const condicion = `USUA_CODIGO = ${id_usuario}`;
          objSql.actualizarDatos(tabla, camposValores, condicion, res);
        }
      })
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al actualizar los datos" })
  }
});

const getRegistro = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = [
        'USUA_CODIGO  as id',
        'USUA_NOMBRE as nombre',
        'USUA_APELLIDO as apellido',
        'USUA_CELULAR as celular',
        'USUA_CORREO as correo',
        'USUA_DIRECCION as direccion',
        'USUA_OBSERVACION as observacion',
        'PERF_CODIGO as id_perfil',
        'USUA_ESTADO as estado',
      ]
      objSql.buscarRegistro(tabla, campos, `USUA_CODIGO=${req.params.codigo}`, [req.params.codigo], res);
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al buscar Usuario" })
  }
});

const combo_usuarios = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = ['USUA_CODIGO as id', 'USUA_NOMBRE as nombre'];
      const condicion = 'USUA_ESTADO=?';
      const valores = ['ACTIVO']
      objUsu.consulta_datos_usuario(id_user, async (datos_usuario) => {
        let sql = `SELECT ${campos.toString()} FROM ${tabla} WHERE ${condicion}`;
        objSql.consultaGeneral(sql, valores, (err, result) => {
          return res.status(200).json(result = result);
        });

      });

    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});
const combo_perfiles = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = ['PERF_CODIGO as id', 'PERF_NOMBRE as nombre'];
      const condicion = 'PERF_ESTADO=?';
      const valores = ['ACTIVO']
      objUsu.obtenerDatosUser(id_usuario, async (err, datos_usuario) => {
        if (datos_usuario) {
          console.log('se obtuvieron datos')
          let sql = `SELECT ${campos.toString()} FROM ${tablaPerfiles} WHERE ${condicion}`;
          console.log(sql);
          objSql.consultaGeneral(sql, valores, (err, result) => {
            return res.status(200).json({ result: result });
          });
        }
      });

    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" })
  }
});

const obtenerId = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      return res.status(200).json({ result: id_usuario, mensaje: 'Id obtenido' });
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al buscar Usuario" })
  }
});

const cambiar_clave = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_user, async (err, datos_usuario) => {
        const { password } = req.body;
        var clave_encrip = objEncrip.encriptar_sha512(password.toString());
        var fecha_auditoria = objFechaAuditoria.fecha_hora_actual();
        const camposValores = {
          "USUA_CLAVE": clave_encrip,
          'USUA_USUMOD': datos_usuario.USUA_NOMBRE,
          'USUA_FECMOD': fecha_auditoria,
        }
        const condicion = `USUA_CODIGO = ${id_usuario}`;
        objSql.actualizarDatos(tabla, camposValores, condicion, res);
      });
    } else {
      console.log('No se encontro el ID del usuario')
      res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al buscar Usuario" })
  }
});


module.exports = {
  crear_usuarios,
  listar_usuarios,
  activar_usuarios,
  eliminar_usuarios,
  actualizar_usuarios,
  actualizar_user_info,
  getRegistro,
  combo_usuarios,
  combo_perfiles,
  registrar_usuarios,
  obtenerId,
  cambiar_clave,
  enviar_correo_confirmacion,
  confirmacion_registro
}