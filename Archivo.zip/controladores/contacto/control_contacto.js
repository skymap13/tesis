const asyncHandler = require("express-async-handler");
const objSql = require("../../funciones/fSql");
const objFechaAuditoria = require("../../funciones/fFechas");
const objToken = require("../../funciones/fToken");
const objUsu = require("../../funciones/fUsuario");
const tablaPrincipal = "vn_contacto_mensajes";
const tablaDetalle = "vn_ventas_carrito_detalle";
const tablaProductos = "vn_inventario_productos";
const tablaUSuarios = "vn_configuracion_usuarios";
const objCorreo = require("../../funciones/fCorreo");

var digitador = "SN";

const recibir_mensaje = asyncHandler(async (req, res) => {
  const {
    nombres,
    apellidos,
    correo,
    mensaje
  } = req.body;
  console.log(req.body);
  let token = req.headers.token;
  let id_user = objToken.obtener_id_usuario(token);
  objUsu.obtenerDatosUser(id_user, async (err, datos_usuario) => {
    if (datos_usuario) {
      digitador = datos_usuario["USUA_NOMBRE"];
      var fecha_auditoria = objFechaAuditoria.fecha_hora_actual();
      let valores = [nombres, apellidos, correo, mensaje, digitador, fecha_auditoria];
      let campos = ["CONT_NOMBRES", "CONT_APELLIDOS", "CONT_CORREO", "CONT_MENSAJE", "CONT_USUING", "CONT_FECING"];
      objSql.consultaGeneral(`SELECT USUA_CORREO FROM ${tablaUSuarios} WHERE PERF_CODIGO=?`, [22], (err, result) => {
        if (result) {
          var html = `Hola,<br><br>Nombre: ${nombres}<br><br>Apellidos: ${apellidos}<br><br>Correo:${correo}<br><br>Se ha recibido un mensaje desde contacto. El mensaje es el siguiente:<br><br><a>${mensaje}</a><br><br>Saludos,`
          var asunto = "VERNNELLY DETALLES: Mensaje de contacto";
          result.forEach((element, index) => {
            objCorreo.enviar_correo_html(element.USUA_CORREO, asunto, html)
          });
        }
        objSql.insertar(tablaPrincipal, campos, valores, res, 'Se guardo mensaje de contacto');
      })

    }
  });
});


const listar_mensajes_contacto = asyncHandler(async (req, res) => {
  try {
    const { page = 1, limit = 10, valorBusqueda } = req.query;
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      const campos = [
        'CONT_CODIGO as id',
        'CONT_NOMBRES as nombres',
        'CONT_APELLIDOS as apellidos',
        'CONT_CORREO as correo',
        'CONT_MENSAJE as mensaje',
        'CONT_USUING as usuario_ingreso',
        'CONT_FECING as fecha_ingreso',
      ];
      const campos_busqueda = ['CONT_NOMBRES', 'CONT_APELLIDOS', 'CONT_CORREO', 'CONT_MENSAJE', 'CONT_USUING', 'CONT_FECING'];
      objSql.listarPaginacion(tablaPrincipal, campos, campos_busqueda, page, valorBusqueda, limit, ` AND 1=1`, res);
    } else {
      console.log('No se encontró el ID del usuario');
      res.status(500).json({ error: "No se encontró el ID del usuario" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error al traer listado" });
  }
});

const getRegistro = asyncHandler(async (req, res) => {
  try {
    let token = req.headers.token || null;
    let id_usuario = objToken.obtener_id_usuario(token) || null;
    if (id_usuario) {
      objUsu.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
        if (datos_usuario) {
          objSql.consultaGeneral(`SELECT 
            CONT_NOMBRES as nombres,
            CONT_APELLIDOS as apellidos,
            CONT_CORREO as correo,
            CONT_MENSAJE as mensaje
            FROM ${tablaPrincipal}
            WHERE CONT_CODIGO=?`, [req.params.codigo], (err, result) => {
            if (err) {
              console.log("error en la consulta:", err);
              return res.status(500).json({ result: null, mensaje: 'Error en la consulta' })
            }
            return res.status(200).json({ result: result, mensaje: 'Datos obtenidos' });
          })
        }
      });
    } else {
      console.log('No se encontro el ID del usuario')
      return res.status(500).json({ error: "No se encontro el ID del usuario" })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: "Error al buscar Usuario" })
  }
});

module.exports = {
  recibir_mensaje,
  listar_mensajes_contacto,
  getRegistro
}