const objEncriptacion = require("../../funciones/fEncriptacion");
const objUser = require("../../funciones/fUsuario");
const asyncHandler = require("express-async-handler");
const { v4: uuidv4 } = require('uuid');
const url = require('../../constantes/frontend_url');
const objSql = require("../../funciones/fSql");
const objCorreo = require("../../funciones/fCorreo");
const tabla_usuarios = 'vn_configuracion_usuarios';
const objFechas = require('../../funciones/fFechas');


const login = asyncHandler(async (req, res) => {
    const { correo, password } = req.body;
    let variables = [correo, objEncriptacion.encriptar_sha512(password), "ACTIVO"];
    var campos = ["USUA_CORREO", "USUA_CLAVEX", "USUA_ESTADO"];
    objUser.validarIdentidadUsuario(variables, res);
})

const recuperarContra = asyncHandler(async (req, res) => {
    console.log('llego a recuperarContra')
    try {
        const { correo } = req.body;
        const token = uuidv4();
        var expirationDate = moment().tz('America/Guayaquil');
        expirationDate = expirationDate.add(5, 'minutes');
        var destinatario = correo;
        var asunto = "VERNNELLY DETALLES: Solicitud de restablecimiento de contraseña";
        const resetPasswordLink = `${url.frontendURL}/restaurar_clave/${token}`;
        console.log(resetPasswordLink);
        var html = `Hola,<br><br>Has solicitado restablecer tu contraseña. Haz clic en el siguiente enlace para cambiar tu contraseña:<br><br><a href="${resetPasswordLink}">Cambiar Clave</a><br><br>Si no has solicitado este restablecimiento, puedes ignorar este correo electrónico.<br><br>Saludos,`
        var cadenasql = `UPDATE ${tabla_usuarios} SET USUA_TOKEN = ?, USUA_TOKDAT = ? WHERE USUA_CORREO = ?`;
        const valores = [token, expirationDate, correo];
        console.log('cadenasql: ', cadenasql);
        console.log('valores: ', valores);
        objSql.consultaGeneral(cadenasql, valores, (err, result) => {
            console.log(result);
            if (err) {
                console.log('Error en la consulta: ', err);
                return res.status(500).json({ mensaje: 'Error en la consulta' });
            } else if (result?.affectedRows > 0) {
                objCorreo.enviar_correo_html_recup_password(destinatario, asunto, html, token, res);
                //return res.status(200).json({ mensaje: 'Se envio un correo para recuperar la contraseña' });
            }
        })
    } catch (error) {
        console.log(error);
        return res.status(500).json({ mensaje: 'Error del servidor' });
    }
});

const cambiar_clave_por_recuperacion = asyncHandler(async (req, res) => {
    try {
        var { clave, token } = req.body;
        var clave_encrip = objEncriptacion.encriptar_sha512(clave.toString());
        objSql.consultaGeneral(`SELECT USUA_TOKEN, USUA_TOKDAT FROM ${tabla_usuarios} WHERE USUA_TOKEN=?`, [token], (err, result) => {
            var fecha_actual = objFechas.fecha_hora_actual_NOFORMAT();
            console.log(result);
            console.log(fecha_actual);
            var validDate = objFechas.compararFechas(result[0].USUA_TOKDAT, fecha_actual);
            if (validDate) {
                const camposValores = {
                    'USUA_CLAVE': clave_encrip
                }
                const condicion = `USUA_TOKEN='${token}'`;
                objSql.actualizarDatos(tabla_usuarios, camposValores, condicion, res);
            } else {
                return res.status(401).json({ mensaje: "tiempo expirado" })
            }
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Error al buscar Usuario" })
    }
});

const validToken = asyncHandler(async (req, res) => {
    console.log("Llego a validar token clave", req.params);
    const { token } = req.params;
    console.log(token);
    objSql.consultaGeneral(`SELECT USUA_TOKEN, USUA_TOKDAT FROM ${tabla_usuarios} WHERE USUA_TOKEN=?`, [token], (err, result) => {
        var fecha_actual = objFechas.fecha_hora_actual_NOFORMAT();
        console.log(result);
        console.log(fecha_actual);
        var validDate = objFechas.compararFechas(result[0].USUA_TOKDAT, fecha_actual);
        if (validDate) {
            res.status(200).json({ valid: true });
        } else {
            res.status(404).json({ valid: false });
        }

    });
})
const validTokenconfirm = asyncHandler(async (req, res) => {
    try {
        console.log("Llego a validar token clave", req.params);
        const { token } = req.params;
        console.log(token);
        objSql.consultaGeneral(`SELECT USUA_TOKENCONFIRM, USUA_TOKDATCONFIRM FROM ${tabla_usuarios} WHERE USUA_TOKENCONFIRM=?`, [token], (err, result) => {
            var fecha_actual = objFechas.fecha_hora_actual_NOFORMAT();
            if (result) {
                var validDate = objFechas.compararFechas(result[0]?.USUA_TOKDATCONFIRM, fecha_actual) || null;
                if (validDate) {
                    res.status(200).json({ valid: true });
                } else {
                    res.status(404).json({ valid: false });
                }
            } else {
                res.status(404).json({ valid: false });
            }
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ mensaje: 'Error en proceso de confirmacion de token' })
    }

})

const cambiar_clave = asyncHandler(async (req, res) => {
    try {
        var { oldPass,
            newPass,
            repeatNewPass } = req.body;
        let token = req.headers.token || null;
        let id_usuario = objToken.obtener_id_usuario(token) || null;
        var clave_encrip = objEncriptacion.encriptar_sha512(newPass.toString());
        if (id_usuario) {
            if (newPass === repeatNewPass) {
                objUser.obtenerDatosUser(id_usuario, (err, datos_usuario) => {
                    if (datos_usuario) {
                        objSql.consultaGeneral(`SELECT USUA_CLAVE FROM ${tabla_usuarios} WHERE USUA_CODIGO=?`, [datos_usuario?.USUA_CODIGO], (err, result) => {
                            if (result[0]?.USUA_CLAVE === oldPass) {
                                const camposValores = {
                                    'USUA_CLAVE': clave_encrip
                                }
                                const condicion = `USUA_CODIGO='${datos_usuario?.USUA_CODIGO}'`;
                                objSql.actualizarDatos(tabla_usuarios, camposValores, condicion, res);
                            } else {
                                return res.status(401).json({ mensaje: "tiempo expirado" })
                            }
                        });
                    }
                })
            }

        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Error al buscar Usuario" })
    }
});
module.exports = {
    login,
    recuperarContra,
    cambiar_clave_por_recuperacion,
    cambiar_clave,
    validToken,
    validTokenconfirm
}