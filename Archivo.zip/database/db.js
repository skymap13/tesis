const mysql = require('mysql2');
const db_const=require('../constantes/database');

const conexion = mysql.createConnection({
  host: db_const.db_host,
  user: db_const.db_user,
  password: db_const.db_pass,
  database: db_const.db_database,
  port: db_const.db_port
})

conexion.connect((error) => {
  if (error) {
    console.log('El error de conexión es: ' + error)
    return
  }
  console.log('¡Conectado a la base de datos MySQL!')
})

module.exports = conexion